package com.saloni.spring.dao;

/**
 * @author saloni
 *
 */
public interface IdGeneratorDao {
	
	public int doIncrementWithLock() ;

}
